﻿#region (c) 2019 Gilles Macabies All right reserved

//   Author     : Gilles Macabies
//   Solution   : DataGridFilter
//   Projet     : DataGridFilter
//   File       : App.xaml.cs
//   Created    : 31/10/2019

#endregion

using System.Windows;

namespace DemoApplication
{
    /// <summary>
    ///     Logique d'interaction pour App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
