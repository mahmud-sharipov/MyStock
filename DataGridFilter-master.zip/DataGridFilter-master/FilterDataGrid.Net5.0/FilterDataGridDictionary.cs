﻿#region (c) 2019 Gilles Macabies All right reserved

// Author     : Gilles Macabies
// Solution   : FilterDataGrid
// Projet     : FilterDataGrid.Net5.0
// File       : FilterDataGridDictionary.cs
// Created    : 03/11/2021
// 

#endregion

namespace FilterDataGrid
{
    /// <summary>
    ///     ResourceDictionary
    /// </summary>
    public partial class FilterDataGridDictionary
    {
        #region Public Constructors

        /// <summary>
        /// FilterDataGrid Dictionary
        /// </summary>
        public FilterDataGridDictionary()
        {
            InitializeComponent();
        }

        #endregion Public Constructors
    }
}